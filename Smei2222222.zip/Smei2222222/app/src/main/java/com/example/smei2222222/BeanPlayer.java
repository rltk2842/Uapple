package com.example.smei2222222;

public class BeanPlayer {//사용자
    private String plId;
    private int plPass;
    private int plNum;
    private int plWin;
    private int plLose;

    public BeanPlayer(){};

    public String getPlId() {
        return plId;
    }

    public void setPlId(String plId) {
        this.plId = plId;
    }

    public int getPlPass() {
        return plPass;
    }

    public void setPlPass(int plPass) {
        this.plPass = plPass;
    }

    public int getplNum() {
        return plNum;
    }

    public void setPlNum(int plNum) {
        this.plNum = plNum;
    }

    public int getPlWin() {
        return plWin;
    }

    public void setPlWin(int plWin) {
        this.plWin = plWin;
    }

    public int getPlLose() {
        return plLose;
    }

    public void setPlLose(int plLose) {
        this.plLose = plLose;
    }
}