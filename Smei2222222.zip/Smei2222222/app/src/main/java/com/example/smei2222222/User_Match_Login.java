package com.example.smei2222222;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Xml;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class User_Match_Login extends AppCompatActivity {

    Button btnback;    GridView userview;
    DBHelper dbHelper ;    SQLiteDatabase sqlDb;
    ArrayList<BeanPlayer> arrayList;
    SimpleAdapter sa;
    ArrayList<HashMap<String,String>> arrList = new ArrayList<>();
    int user;    String idid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_match_login);

        btnback = findViewById(R.id.btnback);
        userview = findViewById(R.id.userview);
        dbHelper = new DBHelper(this);

        sa = new SimpleAdapter(this,
                arrList,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});

        userview.setAdapter(sa);
        sqlDb = dbHelper.getReadableDatabase();
        arrayList = dbHelper.selcetdate1(sqlDb);
        for (int i = 0; i < arrayList.size(); i++) {
            HashMap<String, String> item = new HashMap<>();

            item.put("item1", arrayList.get(i).getPlId());
            item.put("item2", String.valueOf(arrayList.get(i).getPlPass()));
            arrList.add(item);

        }
        sa.notifyDataSetChanged();
        sqlDb.close();

        userview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { usMlBtnChoice(position);  }
        });

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usMlBtnBack();
            }
        });

    }

    private void usMlBtnChoice(int position) {
        Intent MainIt = getIntent();
        user = MainIt.getIntExtra("user",0);

        switch (user){
            case 1:
                idid = arrayList.get(position).getPlId();

                Intent Lg = new Intent(getApplicationContext(),User_Match_Main.class);
                Lg.putExtra("userid",idid.toString());
                setResult(RESULT_OK,Lg);

                sqlDb.close();
                dbHelper.close();
                //온 리즘에서 텍스트뷰 적용 하면 됨

                finish();
                break;
            case 2:
                idid = arrayList.get(position).getPlId();
                Intent Lg1 = new Intent(getApplicationContext(),User_Match_Main.class);
                Lg1.putExtra("userid",idid.toString());
                setResult(RESULT_OK,Lg1);
                sqlDb.close();
                dbHelper.close();

                finish();
                break;
        }
    }

    private void usMlBtnBack() {
        Intent Lg2 = new Intent(getApplicationContext(),User_Match_Main.class);
        setResult(RESULT_CANCELED,Lg2);
        sqlDb.close();
        dbHelper.close();
        finish();
    }
}

