package com.example.smei2222222;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class User_Join extends AppCompatActivity {
    EditText edtUserId, edtUserPass, edtUserNum;
    Button btnUserOk, btnUserCan, btnJoid;

    DBHelper dbHelper ;
    ArrayList<BeanPlayer> arrayList;
    SQLiteDatabase sqlDb;

    String id;
    int pass,num,win,lose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_join);
        edtUserId = findViewById(R.id.edtUserId);
        edtUserPass = findViewById(R.id.edtUserPass);
        edtUserNum = findViewById(R.id.edtUserNum);
        btnUserOk = findViewById(R.id.btnUserOk);
        btnUserCan = findViewById(R.id.btnUserCan);
        btnJoid = findViewById(R.id.btnJoid);

        btnJoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usCheckdID();
            }
        });

        btnUserOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usReBtnOk();
            }
        });

        btnUserCan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usReBtnCan();
            }
        });

    }

    private void usReBtnOk() {
        if (edtUserId.getText().toString().equals("") || edtUserPass.getText().toString().equals("") || edtUserNum.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "모두 입력하세요", Toast.LENGTH_SHORT).show();
        }
        else {

            pass = Integer.parseInt(edtUserPass.getText().toString());
            num =  Integer.parseInt(edtUserNum.getText().toString());



            BeanPlayer be = new BeanPlayer();
            be.setPlId(id);
            be.setPlPass(pass);
            be.setPlNum(num);
            be.setPlWin(win);
            be.setPlLose(lose);
            arrayList.add(be);


            sqlDb = dbHelper.getWritableDatabase();

            dbHelper.insert(sqlDb, be);



            edtUserNum.setText("");
            edtUserId.setText("");
            edtUserPass.setText("");
            //버튼 클릭 이벤트 강제 발생
            //btnUserOk.performClick();

            sqlDb.close();
            dbHelper.close();
            Toast.makeText(getApplicationContext(), "회원가입 되었습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    private void usReBtnCan() {
        dbHelper.close();
        finish();
    }

    private void usCheckdID() {

        dbHelper = new DBHelper(this);

        sqlDb = dbHelper.getReadableDatabase();
        arrayList = dbHelper.selcetdate1(sqlDb);

        id = edtUserId.getText().toString();

        if (edtUserId.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "아이디 입력해", Toast.LENGTH_SHORT).show();
        }
        else {
            for (int i = 0; i < arrayList.size(); i++){

                if (arrayList.get(i).getPlId().equals(id)){
                    btnUserOk.setEnabled(false);
                    Toast.makeText(User_Join.this, "중복", Toast.LENGTH_SHORT).show();
                    break;
                }

                //Toast.makeText(User_Join.this, "없음", Toast.LENGTH_SHORT).show();
                btnUserOk.setEnabled(true);
                // a++;
            }

        }

    }

}