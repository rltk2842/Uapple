package com.example.smei2222222;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class User_Ranking extends AppCompatActivity {

    ListView ranking;    Button btnback;    float winlose,fwin,flose;    String a;
    //DB처리용 객체
    SQLiteDatabase sqlDb; // SQL 쿼리문 실행 객체
    DBHelper mHelper; // 데이터베이스에서 쓰겠다고 선언해준것
    ArrayList<BeanPlayer> bena;
    //데이터 저장용
    ArrayList<HashMap<String, String>> arrData =  new ArrayList<>();
    ArrayList<String> scro;
    //두줄짜리 리스트뷰용 어댑터
    SimpleAdapter sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_ranking);

        scro = new ArrayList<>();
        sa = new SimpleAdapter(this,
                arrData,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});
        ranking = findViewById(R.id.ranking);
        btnback = findViewById(R.id.btnback);

        usRankList();

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usRankBtnOk();
            }
        });

    }// 온크레딧 끝

    private void usRankBtnOk() {
        finish();
    }

    private void usRankList() {
        mHelper = new DBHelper(this);

        sqlDb = mHelper.getReadableDatabase();//저장된 데이터 값을 읽어오는 것
        Cursor cur;//데이터를 행으로 읽어준다.

        cur = sqlDb.rawQuery("SELECT* FROM userTbl", null);



        bena = mHelper.selcetdate1(sqlDb);

        arrData.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

        for(int j =0; j < bena.size(); j++) {
            winlose = 0;
            fwin = bena.get(j).getPlWin();
            flose = bena.get(j).getPlLose();

            if (bena.get(j).getPlWin() != 0 ){
                winlose = (fwin / (fwin + flose)*100);}
            a = String.format("%.2f",winlose);
            scro.add((a));



        }

        ranking.setAdapter(sa);
        for (int i = 0; i < bena.size(); i++) {


            HashMap<String, String> item = new HashMap<>();


            item.put("item1", String.valueOf(bena.get(i).getPlId() +"   "+ bena.get(i).getPlWin() + "승 " + bena.get(i).getPlLose()+ "패"));
            item.put("item2", String.valueOf("승률 : " + scro.get(i) + "%"));


            arrData.add(item);

        }


        sa.notifyDataSetChanged();

        cur.close();
        sqlDb.close();
    }
}//메인 끝
