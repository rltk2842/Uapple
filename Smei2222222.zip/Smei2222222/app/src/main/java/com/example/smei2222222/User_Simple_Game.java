package com.example.smei2222222;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class User_Simple_Game extends AppCompatActivity {
    int inning = 1,count,score1,score2;
    //메인에서 점수입력 시 출력 선언
    String scoresave1,scoresave2;
    TextView gametvpull1, gametvpull2;
    //게임화면 내에서 이벤트 출력 선언
    TextView gametvnow1, gametvnow2; // 현재 점수
    TextView gameinning; // 이닝
    ImageView gameiv1, gameiv2; // 현재 차례 이미지
    Button gameturnoff; // 턴넘기기
    Button gamebtnplus11, gamebtnplus12; // 상대선수 +1

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_simple_game);

        gametvpull1 = findViewById(R.id.gametvpull1);
        gametvpull2 = findViewById(R.id.gametvpull2);
        gametvnow1 = findViewById(R.id.gametvnow1);
        gametvnow2 = findViewById(R.id.gametvnow2);
        gameinning = findViewById(R.id.gameinning);
        gameiv1 = findViewById(R.id.gameiv1);
        gameiv2 = findViewById(R.id.gameiv2);
        gameturnoff = findViewById(R.id.gameturnoff);
        gamebtnplus11 = findViewById(R.id.gamebtnplus11);
        gamebtnplus12 = findViewById(R.id.gamebtnplus12);

        usSpGameName();

        gameturnoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usSpBtnTurn();
            }
        });

    }// 온크레딧 끝

    public void usSpGamebtn(View v) {
        switch (v.getId()){
            case R.id.gamebtnplus11:
                if (count % 2 == 1) {

                    score2++;
                    String now = score2 + "";
                    gametvnow2.setText(now);
                    if (scoresave2.equals(gametvnow2.getText().toString())) {
                        Toast.makeText(User_Simple_Game.this, "사용자2 승리", Toast.LENGTH_SHORT).show();

                        finish();
                    }
                }
                break;
            case R.id.gamebtnplus12:
                if(count%2 == 0) {
                    score1++;
                    String now1 = score1 + "";
                    gametvnow1.setText(now1);
                    if (scoresave1.equals(gametvnow1.getText().toString())) {
                        Toast.makeText(User_Simple_Game.this, "사용자1 승리", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
                break;
        }
    }

    private int usSpBtnTurn() {
        count++;

        if(count%2 == 0) {
            inning++;
            String str = inning + "";
            gameinning.setText(str);
            gameiv1.setVisibility(View.VISIBLE);
            gameiv2.setVisibility(View.GONE);
            gamebtnplus11.setEnabled(false);
            gamebtnplus12.setEnabled(true);

            //뭘해야되냐 턴넘기기를 했을 때


        }else if (count%2 == 1){
            gameiv2.setVisibility(View.VISIBLE);
            gameiv1.setVisibility(View.GONE);
            gamebtnplus11.setEnabled(true);
            gamebtnplus12.setEnabled(false);
        }
        return count;
    }

    private void usSpGameName() {
        Intent intent = getIntent();

        scoresave1 = intent.getStringExtra("scoresave1");
        scoresave2 = intent.getStringExtra("scoresave2");

        gametvpull1.setText(scoresave1);
        gametvpull2.setText(scoresave2);
        gameiv1.setVisibility(View.VISIBLE);
        gameiv2.setVisibility(View.GONE);
        String str = inning + "";
        gameinning.setText(str);
    }


}//메인 끝


