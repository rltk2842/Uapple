package com.example.smei2222222;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Format;
import java.util.ArrayList;

public class User_Match_Game extends AppCompatActivity {

    TextView playername1,playername2, playerscore1,playerscore2,
            playerHR1, playerHR2, playerAVG1, playerAVG2, tvinning
            , user1score, user2score;
    ImageView playeriv1,playeriv2;
    Button btnplus1,btnplus2;
    //DB 값 받는 용
    String user1,user2, struser1score, struser2score;
    int user1win, user2win, user1lose, user2lose,
         score1, score2, count, inning = 1, HR1, HR2,HRa1,HRa2;
    float AVG11,AVG22;    String AVG1,AVG2;

    SQLiteDatabase sqlDb;
    ArrayList<BeanPlayer> user111, user222;
    DBHelper dbHelper ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_match_game);

        playername1 = findViewById(R.id.playername1);
        playername2 = findViewById(R.id.playername2);
        playerscore1 = findViewById(R.id.playerscore1);
        playerscore2 = findViewById(R.id.playerscore2);
        playerHR1 = findViewById(R.id.playerHR1);
        playerHR2 = findViewById(R.id.playerHR2);
        playerAVG1 = findViewById(R.id.playerAVG1);
        playerAVG2 = findViewById(R.id.playerAVG2);
        tvinning = findViewById(R.id.tvinning);
        playeriv1 = findViewById(R.id.playeriv1);
        playeriv2 = findViewById(R.id.playeriv2);
        btnplus1 = findViewById(R.id.btnplus1);
        btnplus2 = findViewById(R.id.btnplus2);
        user1score = findViewById(R.id.user1score);
        user2score = findViewById(R.id.user2score);

        usRcGameName();

    }

    private void usRcGameName() {
        dbHelper = new DBHelper(this);
        Intent MainIt = getIntent();
        user1 = MainIt.getStringExtra("user1");
        user2 = MainIt.getStringExtra("user2");

        playername1.setText(user1);
        playername2.setText(user2);

        sqlDb = dbHelper.getReadableDatabase();
        //BeanPlayer user1 = new BeanPlayer();
        user111 = dbHelper.selcetdate2(sqlDb,user1);
        user222 = dbHelper.selcetdate2(sqlDb,user2);

        struser1score = String.valueOf(user111.get(0).getPlPass());
        struser2score = String.valueOf(user222.get(0).getPlPass());

        user1win = user111.get(0).getPlWin();
        user1lose = user111.get(0).getPlLose();
        user2win = user222.get(0).getPlWin();
        user2lose = user222.get(0).getPlLose();

        //사용자 점수 출력
        user1score.setText(struser1score);
        user2score.setText(struser2score);
    }

    public void usRcGamebtn(View v) {
        switch (v.getId()){
            case R.id.btnplus1:  // 선수 2번 점수
                score2++;   HRa2++;
                AVG22 = (float)score2 / (float)inning;
                AVG2 = String.format("%.2f",AVG22);
                playerAVG2.setText(AVG2); playerscore2.setText(String.valueOf(score2));
                if (HR2 < HRa2){   HR2 = HRa2; playerHR2.setText(String.valueOf(HR2));}
                //사용자 2가 이겼을때
                if(struser2score.equals(String.valueOf(score2))){
                    user2win++;  user1lose++;
                    dbHelper.upDateWin(sqlDb,user2,user2win);
                    dbHelper.upDateLose(sqlDb,user1,user1lose);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(User_Match_Game.this);
                    dlg.setTitle("한게임 더 치시겠습니까??");
                    dlg.setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {usRcBtnOk();} });
                    dlg.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {usRcBtnBack();
                        }
                    });
                    dlg.setCancelable(false); dlg.show();
                    sqlDb.close(); dbHelper.close();  }
                break;
            case R.id.btnplus2:  // 선수 1번 점수
                score1++;  HRa1++;
                AVG11 = (float)score1 / (float)inning;
                AVG1 = String.format("%.2f",AVG11);
                playerAVG1.setText(AVG1); playerscore1.setText(String.valueOf(score1));
                if (HR1 < HRa1){  HR1 = HRa1; playerHR1.setText(String.valueOf(HR1));}
                //사용자 1 이겼을때
                if(struser1score.equals(String.valueOf(score1))){
                    user1win++; user2lose++;
                    dbHelper.upDateWin(sqlDb,user1,user1win);
                    dbHelper.upDateLose(sqlDb,user2,user2lose);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(User_Match_Game.this);
                    dlg.setTitle("한게임 더 치시겠습니까??");
                    dlg.setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) { usRcBtnOk();}});
                    dlg.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {usRcBtnBack();
                        }
                    });
                    dlg.setCancelable(false); dlg.show();
                    sqlDb.close(); dbHelper.close(); }
                break;}}
    
    public void usRcBtnTurn(View v) {
        switch (v.getId()){
            case R.id.btnturn:  // 턴 넘기기
                count++; HRa1 = 0; HRa2 = 0;
                if (count%2==0){ inning++;
                    tvinning.setText(String.valueOf(inning));
                    playeriv1.setColorFilter(Color.GREEN);
                    playeriv2.setColorFilter(Color.rgb(255,255,255));
                    btnplus2.setEnabled(true);
                    btnplus1.setEnabled(false);}
                else {
                    playeriv1.setColorFilter(Color.rgb(255,255,255));
                    playeriv2.setColorFilter(Color.GREEN);
                    btnplus1.setEnabled(true);
                    btnplus2.setEnabled(false);}
                break;
        }
    }

    public void usRcBtnOk() {
        Intent it1 = new Intent(User_Match_Game.this,User_Match_Main.class);
        startActivity(it1);
        finish();
    }

    public void usRcBtnBack() {
        Intent it1 = new Intent(User_Match_Game.this,User_Main.class);
        startActivity(it1);
        finish();

    }


}
