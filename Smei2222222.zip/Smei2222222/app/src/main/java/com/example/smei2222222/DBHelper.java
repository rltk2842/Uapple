package com.example.smei2222222;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "userDB", null, 1
        );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE userTbl(Plid VARCHAR(50), " +
                "                            Plpass NUMBER, " +
                "                            Plnum NUMBER, " +
                "                            Plwin NUMBER, " +
                "                            Pllose NUMBER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS userTbl");
        onCreate(db);
    }

    public void insert(SQLiteDatabase db, BeanPlayer b) {

        db.execSQL("INSERT INTO userTbl VALUES('" + b.getPlId() + "','"+ b.getPlPass() +"','" + b.getplNum() + "','"  + b.getPlWin() +"','" + b.getPlLose() + "')");
    }

    public ArrayList<BeanPlayer> selcetdate1(SQLiteDatabase db) {
        ArrayList<BeanPlayer> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT * FROM userTbl;", null);
        while (cur.moveToNext()) {
            BeanPlayer beans = new BeanPlayer();
            beans.setPlId(cur.getString(0));
            beans.setPlNum(cur.getInt(1));
            beans.setPlPass(cur.getInt(2));
            beans.setPlWin(cur.getInt(3));
            beans.setPlLose(cur.getInt(4));
            list.add(beans);
        }
        return list;

    }

    public ArrayList<BeanPlayer> selcetdate2(SQLiteDatabase db, String Plid) {
        ArrayList<BeanPlayer> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT * FROM userTbl WHERE Plid = '" + Plid + "'", null);
        while (cur.moveToNext()) {
            BeanPlayer beans = new BeanPlayer();
            beans.setPlId(cur.getString(0));
            beans.setPlNum(cur.getInt(1));
            beans.setPlPass(cur.getInt(2));
            beans.setPlWin(cur.getInt(3));
            beans.setPlLose(cur.getInt(4));
            list.add(beans);
        }
        return list;
    }

    public void upDateWin(SQLiteDatabase db, String id, int win) {
        db.execSQL("update userTbl set Plwin = '" + win
                + "' where Plid = '" + id + "';");


    }

    public void upDateLose(SQLiteDatabase db, String id, int lose) {
        db.execSQL("update userTbl set Pllose = '" + lose
                + "' where Plid = '" + id + "';");

    }


}
