package com.example.smei2222222;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class User_Match_Main extends AppCompatActivity {

    Button cancel,exchange,gameStart;
    TextView player1,player2;    String player3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_match_main);

        cancel = findViewById(R.id.cancel);
        exchange = findViewById(R.id.exchange);
        gameStart = findViewById(R.id.gameStart);
        player1 = findViewById(R.id.player1);
        player2 = findViewById(R.id.player2);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usMcBtnBack();

            }
        });

        exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usMcBtnChange();
            }
        });

        gameStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usMcBtnStart();
            }
        });
    }

    public void usMcBtnChoice(View v) {
        switch (v.getId()){
            case R.id.player1sel:
                Intent it = new Intent(getApplicationContext(),User_Match_Login.class);
                it.putExtra("user",1);
                setResult(RESULT_OK,it);
                startActivityForResult(it,2000);

                break;
            case  R.id.player2sel:
                Intent it2 = new Intent(getApplicationContext(),User_Match_Login.class);
                it2.putExtra("user",2);
                setResult(RESULT_OK,it2);
                startActivityForResult(it2,3000);
                break;
        }
    }

    private void usMcBtnChange() {
        player3 = player1.getText().toString();
        player1.setText(player2.getText().toString());
        player2.setText(player3);

    }

    private void usMcBtnStart() {
        if (player1.getText().toString().equals("Player1")||player2.getText().toString().equals("Player2")){
            Toast.makeText(User_Match_Main.this, "선수를 선택해주세염", Toast.LENGTH_SHORT).show();
        }
        else if (player1.getText().toString().equals("Player2")||player2.getText().toString().equals("Player1")){
            Toast.makeText(User_Match_Main.this, "선수를 선택해주세염", Toast.LENGTH_SHORT).show();

        }
        else {
            Intent it = new Intent(getApplicationContext(),User_Match_Game.class);

            it.putExtra("user1",player1.getText().toString());
            it.putExtra("user2",player2.getText().toString());


            finish();
            startActivity(it);
        }
    }

    private void usMcBtnBack() {
        finish();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        if (resultCode == RESULT_OK){
            switch (requestCode){
                case 2000 :
                    if (player2.getText().toString().equals(data.getStringExtra("userid"))){
                        Toast.makeText(this, "중복 ㄴㄴ", Toast.LENGTH_SHORT).show();

                    }
                    else {
                        player1.setText(data.getStringExtra("userid"));
                        break;
                    }

                case 3000 :
                    if (player1.getText().toString().equals(data.getStringExtra("userid"))){
                        Toast.makeText(this, "중복 ㄴㄴ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        player2.setText(data.getStringExtra("userid"));
                        break;
                    }
        }




            }

//        Intent it = new Intent(getApplicationContext(),User_Match_Login.class);
//        String str = data.getStringExtra("userid");
//        Toast.makeText(this, "" + str, Toast.LENGTH_SHORT).show();
//        super.onActivityResult(requestCode, resultCode, data);


    }
}
