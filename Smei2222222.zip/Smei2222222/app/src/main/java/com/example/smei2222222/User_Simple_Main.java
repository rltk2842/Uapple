package com.example.smei2222222;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class User_Simple_Main extends AppCompatActivity {

    EditText edtscore1,edtscore2;
    Button btnstart, btnspback;
    String scoresave1,scoresave2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_simple_main);
        edtscore1 = findViewById(R.id.edtscore1);
        edtscore2 = findViewById(R.id.edtscore2);
        btnstart = findViewById(R.id.btnstart);
        btnspback = findViewById(R.id.btnspback);

        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usSpGamebtnStart();
            }
        });
        btnspback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usSpGamebtnStop();

            }
        });
    }

    private void usSpGamebtnStop() {
        finish();
    }

    private void usSpGamebtnStart() {
        if (edtscore1.getText().toString().equals("") || edtscore2.getText().toString().equals("")){

            Toast.makeText(getApplicationContext(), "점수를 모두 입력하세요", Toast.LENGTH_SHORT).show();

        }
        else {
            Intent intent = new Intent(getApplicationContext(),User_Simple_Game.class);
            scoresave1 = edtscore1.getText().toString();
            scoresave2 = edtscore2.getText().toString();
            intent.putExtra("scoresave1",scoresave1);
            intent.putExtra("scoresave2",scoresave2);

            setResult(RESULT_OK,intent);

            finish();
            startActivity(intent);
            //game.setVisibility(View.VISIBLE);
            //main.setVisibility(View.INVISIBLE);

        }

    }

}
