package com.example.smei2222222;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class User_Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_main);

    }

    public void onClicked(View v) {
        switch (v.getId()){
            case R.id.btnSp:  // 간단경기

                Intent Sp = new Intent(this,User_Simple_Main.class);
               // it.putExtra("index",index);
                startActivity(Sp);

                break;
            case R.id.btnMc:  // 기록경기

                Intent Mc = new Intent(this,User_Match_Main.class);
                // it.putExtra("index",index);
                startActivity(Mc);

                break;
            case R.id.btnRk:  // 랭킹

                Intent Rk = new Intent(this,User_Ranking.class);
                // it.putExtra("index",index);
                startActivity(Rk);

                break;
            case R.id.btnJo:  // 회원가입

                Intent Jo = new Intent(this,User_Join.class);
                // it.putExtra("index",index);
                startActivity(Jo);

                break;
        }
    }
}
