package com.hdh.billiardsapp;

import java.util.Date;

public class BeanSales {

    int saNum;

    public int getSaNum() {
        return saNum;
    }

    public void setSaNum(int saNum) {
        this.saNum = saNum;
    }

    int saYear;
    int saMonth;
    int saDay;
    int saTime;
    int saMoney;
    int saTable;

    public int getSaStay() {
        return saStay;
    }

    public void setSaStay(int saStay) {
        this.saStay = saStay;
    }

    int saStay;

    public int getSaYear() {
        return saYear;
    }

    public void setSaYear(int saYear) {
        this.saYear = saYear;
    }

    public int getSaMonth() {
        return saMonth;
    }

    public void setSaMonth(int saMonth) {
        this.saMonth = saMonth;
    }

    public int getSaDay() {
        return saDay;
    }

    public void setSaDay(int saDay) {
        this.saDay = saDay;
    }

    public int getSaTime() {
        return saTime;
    }

    public void setSaTime(int saTime) {
        this.saTime = saTime;
    }

    public int getSaMoney() {
        return saMoney;
    }

    public void setSaMoney(int saMoney) {
        this.saMoney = saMoney;
    }

    public int getSaTable() {
        return saTable;
    }

    public void setSaTable(int saTable) {
        this.saTable = saTable;
    }
}
