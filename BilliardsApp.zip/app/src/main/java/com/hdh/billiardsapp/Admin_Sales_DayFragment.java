package com.hdh.billiardsapp;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import static com.hdh.billiardsapp.R.layout.fragment_day;


public class Admin_Sales_DayFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private int MyDataY;
    private int MyDataM;
    private int MyDataD;

    int nowY,nowM,nowD;
    int subY,subM,subD;

    TextView nDay;


    Calendar cal = Calendar.getInstance();


    ArrayList<BeanSales> ars;


    TextView nYear;


    Button ybtnS, ybtnA;

    ListView listD;

    SQLiteDatabase sqlDB;
    SalesDB salesDB;

    SimpleAdapter SAD;

    ArrayList<HashMap<String,String>> arrList = new ArrayList<>();





    public Admin_Sales_DayFragment() {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(MyDataY == 0 || MyDataM == 0 || MyDataD ==0){
            MyDataY = cal.get(Calendar.YEAR);
            MyDataM = cal.get(Calendar.MONTH) +1;
            MyDataD = cal.get(Calendar.DAY_OF_MONTH);


        }
        else {
            MyDataY = ((Admin_Sales) getActivity()).getDatay();
            MyDataM = ((Admin_Sales) getActivity()).getDatam() + 1;
            MyDataD = ((Admin_Sales) getActivity()).getDatad();
        }

        salesDB = new SalesDB(getActivity());
        sqlDB = salesDB.getReadableDatabase();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        SAD = new SimpleAdapter(getActivity(),
                arrList,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});

        nowY = cal.get(Calendar.YEAR);
        nowM = cal.get(Calendar.MONTH);
        nowD = cal.get(Calendar.DAY_OF_MONTH);

        subY = nowY;
        subM = nowM + 1 ;
        subD = nowD;


        View view = inflater.inflate(fragment_day, container, false);

        nDay = view.findViewById(R.id.nDay);

        nYear = (TextView)view.findViewById(R.id.nYear);
        ybtnS = (Button)view.findViewById(R.id.ybtnS);
        ybtnA = (Button)view.findViewById(R.id.ybtnA);
        listD = view.findViewById(R.id.listD);


        String jk =String.valueOf(MyDataY) ;
        String jkd =String.valueOf(MyDataD) ;
        String jkm=String.valueOf(MyDataM) ;
        ars = salesDB.selcetdated(sqlDB,jk,jkd,jkm);

        listD.setAdapter(SAD);


        arrList.clear();


        for (int i = 0; i < ars.size(); i++) {
            HashMap<String, String> item = new HashMap<>();


            item.put("item1", String.valueOf(ars.get(i).getSaYear() + "년" +  ars.get(i).getSaMonth() + "월" +ars.get(i).getSaDay() + "일"));
            item.put("item2", String.valueOf("시간 :" +ars.get(i).getSaTime() +" 금액 :"+ars.get(i).getSaMoney()));
            arrList.add(item);

        }



        SAD.notifyDataSetChanged();



        adFragmentBtn();


        nDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent it = new Intent(getActivity(), Admin_Sales_Day_Calendar.class);

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                fragmentManager.beginTransaction().remove(Admin_Sales_DayFragment.this).commit();
                fragmentManager.popBackStack();


                startActivityForResult(it,3000);


            }
        });
        return view;
    }

    public void adFragmentBtn(){
        if(MyDataY == 0){
            String dcal = subY + "년" + subM + "월" + subD + "일";
            nDay.setText(dcal);
        }
        else{
            String dcal = MyDataY + "년" + MyDataM + "월" + MyDataD + "일";
            nDay.setText(dcal);
        }
    }





}
