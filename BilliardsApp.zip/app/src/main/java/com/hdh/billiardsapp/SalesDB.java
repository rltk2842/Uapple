package com.hdh.billiardsapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class SalesDB extends SQLiteOpenHelper {

    Admin_Main mb;

    public SalesDB(Context context) {
        super(context, "BeanSales", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query ="create table if not exists sales " +
                "(Sa_Num INTEGER PRIMARY KEY autoincrement, " +
                "Sa_Year NUMBER(4) NOT NULL, " +
                "Sa_Month NUMBER(2) NOT NULL, "  +
                "Sa_Day NUMBER(2) NOT NULL,  " +
                "Sa_Time NUMBER NOT NULL, "  +
                "Sa_Money NUMBER NOT NULL, " +
                "Sa_Table NUMBER NOT NULL, " +
                "Sa_Stay NUMBER DEFAULT 0 );" ;

        db.execSQL(query);

    }



    public ArrayList<BeanSales> selcetdate(SQLiteDatabase db) {
        ArrayList<BeanSales> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT Sa_Num , Sa_Money,Sa_Year FROM sales ;" , null);
        while (cur.moveToNext()) {
            BeanSales beans = new BeanSales();
            beans.setSaNum(cur.getInt(0));
            beans.setSaMoney(cur.getInt(1));

            beans.setSaYear(cur.getInt(2));

            list.add(beans);
        }
        return list;
    }

    public ArrayList<BeanSales> selcetdatey(SQLiteDatabase db,int subY) {
        ArrayList<BeanSales> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT Sa_Num , Sa_Money,Sa_Time,Sa_Year FROM sales WHERE Sa_Year ='" + subY + "' AND Sa_Stay =" + 1 + ";" , null);
        while (cur.moveToNext()) {
            BeanSales beans = new BeanSales();
            beans.setSaNum(cur.getInt(0));
            beans.setSaMoney(cur.getInt(1));
            beans.setSaTime(cur.getInt(2));
            beans.setSaYear(cur.getInt(3));

            list.add(beans);
        }
        return list;
    }

    public ArrayList<BeanSales> selcetdatem(SQLiteDatabase db,int subY, int subm) {
        ArrayList<BeanSales> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT Sa_Num , Sa_Money,Sa_Year,Sa_Month,Sa_Time FROM sales WHERE Sa_Year =" + subY + " AND Sa_Month = " + subm + " AND Sa_Stay =" + 1 + ";" , null);
        while (cur.moveToNext()) {
            BeanSales beans = new BeanSales();
            beans.setSaNum(cur.getInt(0));
            beans.setSaMoney(cur.getInt(1));
            beans.setSaYear(cur.getInt(2));
            beans.setSaMonth(cur.getInt(3));
            beans.setSaTime(cur.getInt(4));


            list.add(beans);
        }
        return list;
    }

    public ArrayList<BeanSales> selcetdated(SQLiteDatabase db,String subY,String subd,String subm) {

        ArrayList<BeanSales> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT Sa_Num , Sa_Money,Sa_Time,Sa_Year,Sa_Day,Sa_Month" +
                " FROM sales WHERE Sa_Year =" + subY + " AND Sa_Month =" + subm +" AND Sa_Day = " + subd + " AND Sa_Stay =" + 1 + ";" , null);
        while (cur.moveToNext()) {
            BeanSales beans = new BeanSales();
            beans.setSaNum(cur.getInt(0));
            beans.setSaMoney(cur.getInt(1));
            beans.setSaTime(cur.getInt(2));
            beans.setSaYear(cur.getInt(3));
            beans.setSaDay(cur.getInt(4));
            beans.setSaMonth(cur.getInt(5));


            list.add(beans);
        }
        return list;
    }




    public ArrayList<BeanSales> cash(SQLiteDatabase db,int k) {

        ArrayList<BeanSales> list = new ArrayList<>();
        Cursor cur;

        cur = db.rawQuery("SELECT Sa_Time,SA_NUM, SA_MONEY, Sa_Table FROM sales " +
                "WHERE Sa_Table =" + k + " AND Sa_Stay =" + 0  + ";", null);

        while (cur.moveToNext()) {
            BeanSales beans = new BeanSales();
            beans.setSaTime(cur.getInt(0));
            beans.setSaNum(cur.getInt(1));
            beans.setSaMoney(cur.getInt(2));
            beans.setSaTable(cur.getInt(3));

            list.add(beans);
        }
        return list;
    }



    public void DeleteTbl(SQLiteDatabase db, String num, int stay) {


        db.execSQL("UPDATE sales SET Sa_Stay =" + stay +  " WHERE Sa_NUM =" + num + ";" );
        //db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS sales");
        onCreate(db);
    }
}
