package com.hdh.billiardsapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_Login extends AppCompatActivity {

    Button btnLo,btnMem;

    BuilDB BuilDB;
    SQLiteDatabase Bdb;

    EditText edtid,edtpw;

    String ad_id,ad_pw;

    ArrayList<BeanBuil> builist = new ArrayList<>();

    int move;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        BuilDB = new BuilDB(this);

        Bdb = BuilDB.getReadableDatabase();

        BuilDB.onCreate(Bdb);

        btnMem = findViewById(R.id.btnMem);

        edtid = findViewById(R.id.edtid);
        edtpw = findViewById(R.id.edtpw);




        btnMem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adBtnRe();
            }
        });

        btnLo = findViewById(R.id.btnLo);

        btnLo.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                move = 0;


                adSelectData();

                adEdtJoin();

            }
        });

    }

    public void adBtnRe(){
        Intent it = new Intent(Admin_Login.this, Admin_Join.class);
        startActivity(it);
    }

    public void adEdtJoin(){

        ad_id = edtid.getText().toString();
        ad_pw = edtpw.getText().toString();

        if(builist.size() == 0 ){
            Toast.makeText(Admin_Login.this, "1:아이디를 잘못입력했습니다.", Toast.LENGTH_SHORT).show();
            move= 2;
        }
        else if(builist.size() > 0){
            for(int i = 0; i<builist.size(); i ++) {
                if(builist.get(i).id.equals(ad_id)) {
                    move ++;

                    if(builist.get(i).pw.equals(ad_pw)){
                        Intent it = new Intent(Admin_Login.this, Admin_Main.class);
                        startActivity(it);
                        move ++;
                        break;
                    }

                }



            }
        }

        if(move == 0)
            Toast.makeText(Admin_Login.this, "2:아이디를 잘못입력했습니다.", Toast.LENGTH_SHORT).show();

        if(move == 1)
            Toast.makeText(Admin_Login.this, "비밀번호를 잘못입력했습니다.", Toast.LENGTH_SHORT).show();

    }



    public  void adSelectData(){
        Bdb = BuilDB.getReadableDatabase();

        Cursor cur;

        String query = "Select Ad_id,Ad_pass from admin;";

        builist.clear();

        try{
            cur = Bdb.rawQuery(query,null);

            while (cur.moveToNext()){
                BeanBuil bu = new BeanBuil();
                bu.id = cur.getString(0);
                bu.pw = cur.getString(1);
                builist.add(bu);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        Bdb.close();
    }

}
