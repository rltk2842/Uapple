package com.hdh.billiardsapp;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;

public class Admin_Sales extends AppCompatActivity {

    Button btnYear, btnMonth,btnDay;



    Admin_Sales_YearFragment yfrag;
    Admin_Sales_MonthFragment mfrag;
    Admin_Sales_DayFragment dfrag;

    View V_yfrag;

    TextView tv_vfrag;

    int nYear,nMonth,nDay;

    int fyear,fmonth,fday;


    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sales);

        V_yfrag = View.inflate(getApplicationContext(),R.layout.fragment_year,null);
        tv_vfrag = V_yfrag.findViewById(R.id.nYear);




        btnYear = findViewById(R.id.btnYear);
        btnMonth = findViewById(R.id.btnMon);
        btnDay = findViewById(R.id.btnDay);


        yfrag = new Admin_Sales_YearFragment();
        mfrag = new Admin_Sales_MonthFragment();
        dfrag = new Admin_Sales_DayFragment();



        Calendar cal = Calendar.getInstance();
        nYear = cal.get(Calendar.YEAR);
        nMonth = cal.get(Calendar.MONTH);
        nDay = cal.get(Calendar.DAY_OF_MONTH);





        btnYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adFragment(1);
            }
        });

        btnMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adFragment(2);
            }
        });

        btnDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adFragment(3);

            }
        });


    }


    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        menu.add(0, 1, 0, "뒤로가기");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case 1:

                finish();
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(resultCode == RESULT_OK){
                    Intent it = getIntent();
                    fyear = data.getIntExtra("year",1);
                    fmonth = data.getIntExtra("mon",1);
                    fday = data.getIntExtra("day",1);
            adFragment(3);
        }
    }

    public int getDatay(){
        return fyear;
    }
    public int getDatam(){
        return fmonth;
    }
    public int getDatad(){
        return fday;
    }

    private void adFragment(int id) {
        FragmentManager fman = getSupportFragmentManager();
        FragmentTransaction fTrans =fman.beginTransaction();

        if(id == 1){
            fTrans.replace(R.id.fragment, yfrag);

            count = 1;
        }
        else if(id == 2){
            fTrans.replace(R.id.fragment, mfrag);

            count = 2;
        }
        else {
            fTrans.replace(R.id.fragment, dfrag);

            count = 3;
        }

        fTrans.commitAllowingStateLoss();

    }
}
