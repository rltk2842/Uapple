package com.hdh.billiardsapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_Join extends AppCompatActivity {


    ArrayList<BeanBuil> builist = new ArrayList<>();

    BuilDB BuilDB;
    SQLiteDatabase Bdb;

    EditText edtid,edtpw,edtna,edtph;

    Button btnMe,btnCa;

    String strid,strna,strpw,strph;

    int intpw,intph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_join);

        BuilDB = new BuilDB(this);

        edtid = findViewById(R.id.edtid);
        edtpw = findViewById(R.id.edtpw);
        edtna = findViewById(R.id.edtna);
        edtph = findViewById(R.id.edtph);

        btnMe = findViewById(R.id.btnMe);
        btnCa = findViewById(R.id.btnCa);






        btnMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                strid = edtid.getText().toString();
                strpw = edtpw.getText().toString();
                strna = edtna.getText().toString();
                strph = edtph.getText().toString();


                adJSelectData();

                adReBtnOk();
            }
        });

        btnCa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adReBtnCan();
            }
        });


    }

    public void adReBtnCan(){
        finish();
    }


    public void adReBtnOk(){

        if(builist.size() == 0){

            adJSaveData();
            Toast.makeText(Admin_Join.this, "가입완료", Toast.LENGTH_SHORT).show();

            finish();
        }
        else {
            for(int i = 0; i<builist.size(); i++) {
                if (builist.get(i).id.equals(strid) ) {
                    Toast.makeText(Admin_Join.this, "중복된", Toast.LENGTH_SHORT).show();
                    break;
                } else {
                    adJSaveData();
                    Toast.makeText(Admin_Join.this, "가입완료", Toast.LENGTH_SHORT).show();

                    finish();
                }
            }


        }
    }

    public void adJSaveData(){
        Bdb = BuilDB.getWritableDatabase();

        intpw = Integer.parseInt(strpw);
        intph = Integer.parseInt(strph);

        String query = "INSERT INTO admin values"
                + "('" + strid + "'," +  intpw + "," + strna  + "," + intph + ");";

        try{
            Bdb.execSQL(query);
        }catch (Exception e){
            e.printStackTrace();
        }

        Bdb.close();
    }

    public  void adJSelectData(){
        Bdb = BuilDB.getReadableDatabase();

        Cursor cur;

        String query = "Select Ad_id from admin ;";

        builist.clear();

        try{

            cur = Bdb.rawQuery(query,null);

            while (cur.moveToNext()){
                BeanBuil bu = new BeanBuil();
                bu.id = cur.getString(0);

                builist.add(bu);
            }


        }catch (Exception e){
            e.printStackTrace();
        }

        Bdb.close();


    }


}
