package com.hdh.billiardsapp;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class Admin_Cash extends AppCompatActivity {

    SQLiteDatabase sqlDb; // SQL 쿼리문 실행 객체
    // 데이터베이스에서 쓰겠다고 선언해준것
    //데이터 저장용
    HashMap<String, String> item;
    View cashV;
    ListView cashInfo;
    //두줄짜리 리스트뷰용 어댑터
    SimpleAdapter sa;
    SalesDB dbHelperSales;
    ArrayList<HashMap<String,String>> arrList = new ArrayList<>();
    ArrayList<BeanSales> arBean;

    String num;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_cash);



        arBean = new ArrayList<>();


        cashV = View.inflate(Admin_Cash.this,R.layout.activity_cash_list,null);
        cashInfo = cashV.findViewById(R.id.cashinfor);

        dbHelperSales = new SalesDB(this);


        sa = new SimpleAdapter(this,
                arrList,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});



        sqlDb = dbHelperSales.getReadableDatabase();



        arBean= dbHelperSales.selcetdate(sqlDb);

        for (int i = 0; i < arBean.size(); i++) {
            HashMap<String, String> item = new HashMap<>();
            item.put("item1", String.valueOf(arBean.get(i).getSaNum()));
            item.put("item2", String.valueOf(arBean.get(i).getSaMoney()));


            arrList.add(item);

        }

        cashInfo.setAdapter(sa);
        //sa.notifyDataSetChanged();

        sqlDb.close();







        cashInfo.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                AlertDialog.Builder dlg = new AlertDialog.Builder(Admin_Cash.this);
                dlg.setTitle("결제정보");
                dlg.setPositiveButton("예", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adCheckdPay(position);
                    }
                });

                dlg.show();
                return true;

            }
        });

    }

    public void adCheckdPay(int position){
        String i1 = String.valueOf(arBean.get(position).getSaNum());;
        String i2 = arrList.get(position).get("item2");
        Toast.makeText(Admin_Cash.this, i1 + i2, Toast.LENGTH_SHORT).show();

        sqlDb = dbHelperSales.getWritableDatabase();
        int stay = 1;

        dbHelperSales.DeleteTbl(sqlDb,i1,stay);

        arrList.remove(position);
        sa.notifyDataSetChanged();

        sqlDb.close();
    }

    public void adPayList(View v){
        switch (v.getId()){
            case R.id.bil1 :
                Toast.makeText(this, "1번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio1 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio1.setTitle("결제하시겠습니까?");
                dlgRadio1.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것



                arBean = dbHelperSales.cash(sqlDb,1);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 :" +arBean.get(i).getSaTime()+ "분"));
                    item.put("item2", String.valueOf( "금액 :" +arBean.get(i).getSaMoney()));

                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }
                dlgRadio1.setView(cashInfo);

                dlgRadio1.setNeutralButton("닫기",null);
                dlgRadio1.show();



                break;
            case R.id.bil2 :
                Toast.makeText(this, "2번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio2 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio2.setTitle("결제하시겠습니까?");
                dlgRadio2.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것

                arBean = dbHelperSales.cash(sqlDb,2);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 :" +arBean.get(i).getSaTime()+ "분"));
                    item.put("item2", String.valueOf( "금액 :" +arBean.get(i).getSaMoney()));
                    num = String.valueOf(arBean.get(i).getSaNum());
                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }
                dlgRadio2.setView(cashInfo);

                dlgRadio2.setNeutralButton("닫기",null);
                dlgRadio2.show();
                break;
            case R.id.bil3 :
                Toast.makeText(this, "3번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio3 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio3.setTitle("결제하시겠습니까?");
                dlgRadio3.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것

                arBean = dbHelperSales.cash(sqlDb,3);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 :" +arBean.get(i).getSaTime()+ "분"));
                    item.put("item2", String.valueOf( "금액 :" +arBean.get(i).getSaMoney()));
                    num = String.valueOf(arBean.get(i).getSaNum());
                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }
                dlgRadio3.setView(cashInfo);

                dlgRadio3.setNeutralButton("닫기",null);
                dlgRadio3.show();
                break;
            case R.id.bil4 :
                Toast.makeText(this, "4번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio4 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio4.setTitle("결제하시겠습니까?");
                dlgRadio4.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것

                arBean = dbHelperSales.cash(sqlDb,4);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 :" +arBean.get(i).getSaTime()+ "분"));
                    item.put("item2", String.valueOf( "금액 :" +arBean.get(i).getSaMoney()));
                    num = String.valueOf(arBean.get(i).getSaNum());
                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }
                dlgRadio4.setView(cashInfo);

                dlgRadio4.setNeutralButton("닫기",null);
                dlgRadio4.show();
                break;
            case R.id.bil5 :
                Toast.makeText(this, "5번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio5 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio5.setTitle("결제하시겠습니까?");
                dlgRadio5.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것

                arBean = dbHelperSales.cash(sqlDb,5);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 :" +arBean.get(i).getSaTime()+ "분"));
                    item.put("item2", String.valueOf( "금액 :" +arBean.get(i).getSaMoney()));
                    num = String.valueOf(arBean.get(i).getSaNum());
                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }

                dlgRadio5.setView(cashInfo);

                dlgRadio5.setNeutralButton("닫기",null);
                dlgRadio5.show();
                break;
            case R.id.bil6 :
                Toast.makeText(this, "6번 테이블", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder dlgRadio6 = new AlertDialog.Builder(Admin_Cash.this);
                dlgRadio6.setTitle("결제하시겠습니까?");
                dlgRadio6.setIcon(R.mipmap.ic_launcher_round);



                sa = new SimpleAdapter(this,
                        arrList,
                        android.R.layout.simple_list_item_2,
                        new String[]{"item1","item2"},
                        new int[] {android.R.id.text1,android.R.id.text2});

                dbHelperSales = new SalesDB(this);

                sqlDb = dbHelperSales.getReadableDatabase();//저장된 데이터 값을 읽어오는 것

                arBean = dbHelperSales.cash(sqlDb,6);
                arrList.clear();//조회하면 추가 된것만 뜨게 하게 클리어 해준다.

                cashInfo.setAdapter(sa);
                for (int i = 0; i < arBean.size(); i++) {

                    HashMap<String, String> item = new HashMap<>();


                    item.put("item1", String.valueOf( "시간 : " +arBean.get(i).getSaTime() + "분"));
                    item.put("item2", String.valueOf( "금액 : " +arBean.get(i).getSaMoney()));
                    num = String.valueOf(arBean.get(i).getSaNum());
                    arrList.add(item);
                }

                if(cashInfo.getParent() != null){
                    ((ViewGroup) cashInfo.getParent()).removeView(cashInfo);
                }
                dlgRadio6.setView(cashInfo);

                dlgRadio6.setNeutralButton("닫기",null);
                dlgRadio6.show();
                break;

        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        menu.add(0, 1, 0, "뒤로가기");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {

            case 1:
               adClose();
                break;
        }
        return true;
    }

    public void adClose(){
        finish();
    }

}
