package com.hdh.billiardsapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CalendarView;

import java.util.Calendar;

public class Admin_Sales_Day_Calendar extends AppCompatActivity {

    CalendarView cal;

    int cyear,cmon,cday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sales_day_calendar);

       cal = findViewById(R.id.cal);


       cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
           @Override
           public void onSelectedDayChange( CalendarView view, int year, int month, int dayOfMonth) {
               cyear = year;
               cmon = month;
               cday = dayOfMonth;

               Intent it = new Intent(Admin_Sales_Day_Calendar.this,Calendar.class);

               it.putExtra("year",cyear);
               it.putExtra("mon",cmon);
               it.putExtra("day",cday);


               setResult(RESULT_OK, it);

               finish();

           }
       });



    }
}
