package com.hdh.billiardsapp;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.util.Calendar;

public class Admin_Main extends AppCompatActivity {





    SalesDB dbHelperSales;


    SQLiteDatabase sqlDb;
    SQLiteDatabase ssqlDb;


                    Button[] imgT = new Button[6];
                    Button bil1,bil2,bil3,bil4,bil5,bil6;


                    int imgId[] = {R.id.bil1, R.id.bil2, R.id.bil3, R.id.bil4, R.id.bil5, R.id.bil6};


                    int nowY,nowM,nowD;



                    int count1,count2,count3,count4,count5,count6;
                    int backValue1,backValue2,backValue3,backValue4,backValue5,backValue6;

                    BackRunnable1 runnable1;
                    BackRunnable2 runnable2;
                    BackRunnable3 runnable3;
                    BackRunnable4 runnable4;
                    BackRunnable5 runnable5;
                    BackRunnable6 runnable6;


                    int nowValue1,nowValue2,nowValue3,nowValue4,nowValue5,nowValue6;
                    int nowGold1,nowGold2,nowGold3,nowGold4,nowGold5,nowGold6;

                    @Override
                    protected void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);
                        setContentView(R.layout.activity_admin_main);

                        bil1 = findViewById(R.id.bil1);
                        bil2 = findViewById(R.id.bil2);
                        bil3 = findViewById(R.id.bil3);
                        bil4 = findViewById(R.id.bil4);
                        bil5 = findViewById(R.id.bil5);
                        bil6 = findViewById(R.id.bil6);


                        dbHelperSales = new SalesDB(this);

                        ssqlDb = dbHelperSales.getWritableDatabase();


                        dbHelperSales.onCreate(ssqlDb);





                        Calendar cal = Calendar.getInstance();
                        nowY = cal.get(Calendar.YEAR);
                        nowM = cal.get(Calendar.MONTH) +1;
                        nowD = cal.get(Calendar.DAY_OF_MONTH);


                        for(int i =0; i<imgT.length; i++){
                            imgT[i] = findViewById(imgId[i]);

                        }






                    }

                    //당구 종료시 시간과 금액 저장 : insert
                    public void adMSaveData(int a, int b, int c){
                        sqlDb = dbHelperSales.getWritableDatabase();


                        String query = "INSERT INTO sales (Sa_Year , Sa_Month, Sa_Day, Sa_Time, Sa_Money,Sa_Table) values"
                                + "(" + nowY + "," +  nowM + "," + nowD  + "," + a +"," +b+ "," + c + ");";

                        try{
                            ssqlDb.execSQL(query);
                        }catch (Exception e){
                            e.printStackTrace();
                        }


                        ssqlDb.close();
                    }


                    public void adStart(View v){
                        switch (v.getId()){
                            case R.id.bil1 :
                                imgT[0].setBackgroundResource(R.drawable.tablecli);
                                count1++;
                                if (count1 == 1) {
                                    runnable1 = new BackRunnable1();
                                    Thread thread2 = new Thread(runnable1);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count1 == 2) {
                                    imgT[0].setBackgroundResource(R.drawable.table);
                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue1,nowGold1,1);


                                    ssqlDb.close();
                                    if (runnable1 != null)
                                        runnable1.setWhile1(false);
                                    count1 = 0;
                                }
                                imgT[0].setText("시간 : " + backValue1/60 + "분" + "\n" + " 금액 : " + (backValue1 / 600) * 1000);

                                break;
                            case R.id.bil2 :
                                imgT[1].setBackgroundResource(R.drawable.tablecli);
                                count2++;
                                if (count2 == 1) {
                                    runnable2 = new BackRunnable2();
                                    Thread thread2 = new Thread(runnable2);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count2 == 2) {
                                    imgT[1].setBackgroundResource(R.drawable.table);
                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue2,nowGold2,2);


                                    ssqlDb.close();
                                    if (runnable2 != null)
                                        runnable2.setWhile2(false);
                                    count2 = 0;
                                }
                                imgT[1].setText("시간 : " + backValue2 + "분" + "\n" + " 금액 : " + (backValue2 / 600) * 1000);
                                break;
                            case R.id.bil3 :
                                imgT[2].setBackgroundResource(R.drawable.tablecli);
                                count3++;
                                if (count3 == 1) {
                                    runnable3 = new BackRunnable3();
                                    Thread thread2 = new Thread(runnable3);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count3 == 2) {
                                    imgT[2].setBackgroundResource(R.drawable.table);
                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue3,nowGold3,3);


                                    ssqlDb.close();
                                    if (runnable3 != null)
                                        runnable3.setWhile3(false);
                                    count3 = 0;
                                }
                                imgT[2].setText("시간 : " + backValue3 + "분" + "\n" + " 금액 : " + (backValue3 / 600) * 1000);
                                break;
                            case R.id.bil4 :
                                imgT[3].setBackgroundResource(R.drawable.tablecli);
                                count4++;
                                if (count4 == 1) {
                                    runnable4 = new BackRunnable4();
                                    Thread thread2 = new Thread(runnable4);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count4 == 2) {
                                    imgT[3].setBackgroundResource(R.drawable.table);
                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue4,nowGold4,4);


                                    ssqlDb.close();
                                    if (runnable4 != null)
                                        runnable4.setWhile4(false);
                                    count4 = 0;
                                }
                                imgT[3].setText("시간 : " + backValue4 + "분" + "\n" + " 금액 : " + (backValue4 / 600) * 1000);
                                break;
                            case R.id.bil5 :
                                imgT[4].setBackgroundResource(R.drawable.tablecli);
                                count5++;
                                if (count5 == 1) {
                                    runnable5 = new BackRunnable5();
                                    Thread thread2 = new Thread(runnable5);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count5 == 2) {
                                    imgT[4].setBackgroundResource(R.drawable.table);
                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue5,nowGold5,5);


                                    ssqlDb.close();
                                    if (runnable5 != null)
                                        runnable5.setWhile5(false);
                                    count5 = 0;
                                }
                                imgT[4].setText("시간 : " + backValue5 + "분" + "\n" + " 금액 : " + (backValue5 / 600) * 1000);
                                break;
                            case R.id.bil6 :
                                imgT[5].setBackgroundResource(R.drawable.tablecli);
                                count6++;
                                if (count6 == 1) {
                                    runnable6 = new BackRunnable6();
                                    Thread thread2 = new Thread(runnable6);//예: 자동차
                                    //앱이 종료될 때 스레드도 값이 종료되도록 실행.
                                    thread2.setDaemon(true);
                                    thread2.start();
                                } else if (count6 == 2) {
                                    imgT[5].setBackgroundResource(R.drawable.table);

                                    ssqlDb = dbHelperSales.getWritableDatabase();


                                    adMSaveData(nowValue6,nowGold6,6);


                                    ssqlDb.close();
                                    if (runnable6 != null)
                                        runnable6.setWhile6(false);
                                    count6 = 0;
                                }
                                imgT[5].setText("시간 : " + backValue6 + "분" + "\n" + " 금액 : " + (backValue6 / 600) * 1000);
                                break;



                        }
                    }


                    public boolean onCreateOptionsMenu(Menu menu) {
                        super.onCreateOptionsMenu(menu);

                        menu.add(0, 1, 0, "결제");
                        menu.add(0, 2, 0, "총 매출액");
                        menu.add(0, 3, 0, "뒤로가기");

                        return true;
                    }

                    @Override
                    public boolean onOptionsItemSelected(MenuItem item) {
                        super.onOptionsItemSelected(item);

                        switch (item.getItemId()) {
                            case 1:
                                adPay();
                                break;

                            case 2:

                                adAll();

                                break;
                            case 3:
                                adBack();
                                break;

                        }
                        return true;
                    }

                    public void adPay(){
                        Intent cit = new Intent(Admin_Main.this, Admin_Cash.class);

                        startActivity(cit);
                    }

                    public void adAll(){
                        Intent it = new Intent(Admin_Main.this, Admin_Sales.class);

                        startActivity(it);
                    }

                    public void adBack(){
                        finish();
                    }



    class BackRunnable1 implements Runnable{

                        boolean bWhile = true;
                        @Override
                        public void run() {
                            while(bWhile){
                                backValue1++;
                                try{
                                    //back.setText(backValue);
                                    //뷰에 값을 쓰는 것은 불가
                                    han.sendEmptyMessage(1);
                                    Thread.sleep(1000);
                                }catch (InterruptedException e){
                                    e.printStackTrace();
                                }
                                Thread.interrupted();

                            }
                        }
                        public void setWhile1(boolean b){
                            bWhile = b;
                            backValue1 = 0;
                        }
                    }
                    class BackRunnable2 implements Runnable{

                        boolean bWhile = true;
                        @Override
                        public void run() {
                            while(bWhile){
                                backValue2++;
                                try{
                                    //back.setText(backValue);
                                    //뷰에 값을 쓰는 것은 불가
                                    han.sendEmptyMessage(2);
                                    Thread.sleep(1000);
                                }catch (InterruptedException e){
                                    e.printStackTrace();
                                }
                                Thread.interrupted();

                            }
                        }
                        public void setWhile2(boolean b){
                            bWhile = b;
                            backValue2 = 0;
                        }
                    }
                    class BackRunnable3 implements Runnable{

                        boolean bWhile = true;
                        @Override
                        public void run() {
                            while(bWhile){
                                backValue3++;
                                try{
                                    //back.setText(backValue);
                                    //뷰에 값을 쓰는 것은 불가
                                    han.sendEmptyMessage(3);
                                    Thread.sleep(1000);
                                }catch (InterruptedException e){
                                    e.printStackTrace();
                                }
                                Thread.interrupted();

                            }
                        }
                        public void setWhile3(boolean b){
                            bWhile = b;
                            backValue3 = 0;
                        }
                    }
                    class BackRunnable4 implements Runnable{

                        boolean bWhile = true;
                        @Override
                        public void run() {
                            while(bWhile){
                                backValue4++;
                                try{
                                    //back.setText(backValue);
                    //뷰에 값을 쓰는 것은 불가
                    han.sendEmptyMessage(4);
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                Thread.interrupted();

            }
        }
        public void setWhile4(boolean b){
            bWhile = b;
            backValue4 = 0;
        }
    }
    class BackRunnable5 implements Runnable{

        boolean bWhile = true;
        @Override
        public void run() {
            while(bWhile){
                backValue5++;
                try{
                    //back.setText(backValue);
                    //뷰에 값을 쓰는 것은 불가
                    han.sendEmptyMessage(5);
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                Thread.interrupted();

            }
        }
        public void setWhile5(boolean b){
            bWhile = b;
            backValue5 = 0;
        }
    }
    class BackRunnable6 implements Runnable{

        boolean bWhile = true;
        @Override
        public void run() {
            while(bWhile){
                backValue6++;
                try{
                    //back.setText(backValue);
                    //뷰에 값을 쓰는 것은 불가
                    han.sendEmptyMessage(6);
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                Thread.interrupted();

            }
        }
        public void setWhile6(boolean b){
            bWhile = b;
            backValue6 = 0;
        }
    }


    //Handler 객체
    //메인스레드와 작업스레드 간의 통신할 수 있는 방법을 제공
    //작업스레드 메인스레드에 있는 변수를 참조 할 수 있지만
    //메인스레드의 뷰를 직접 변경할 수 없음.
    //메인스레드에게 메시지를 전송하여 변경을 요청
    final Handler han = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    nowValue1 = backValue1;
                    nowGold1 = ((backValue1/15)*800+800);
                    imgT[0].setText("시간 : " + backValue1 +"분"+ "\n" +" 금액 : " + ((backValue1/15)*800+800));
                    break;
                case 2 :
                    nowValue2 = backValue2;
                    nowGold2 = ((backValue2/15)*800+800);
                    imgT[1].setText("시간 : " + backValue2 +"분"+ "\n" +" 금액 : " + ((backValue2/15)*800+800));
                    break;
                case 3:
                    nowValue3 = backValue3;
                    nowGold3 = ((backValue3/15)*800+800);
                    imgT[2].setText("시간 : " + backValue3 +"분"+ "\n" +" 금액 : " + ((backValue3/15)*800+800));
                    break;
                case 4 :
                    nowValue4 = backValue4;
                    nowGold4 = ((backValue4/15)*800+800);
                    imgT[3].setText("시간 : " + backValue4 +"분"+ "\n" +" 금액 : " + ((backValue4/15)*800+800));
                    break;
                case 5:
                    nowValue5 = backValue5;
                    nowGold5 = ((backValue5/15)*800+800);
                    imgT[4].setText("시간 : " + backValue5 +"분"+ "\n" +" 금액 : " + ((backValue5/15)*800+800));
                    break;
                case 6 :
                    nowValue6 = backValue6;
                    nowGold6 = ((backValue6/15)*800+800);
                    imgT[5].setText("시간 : " + backValue6 +"분"+ "\n" +" 금액 : " + ((backValue6/15)*800+800));
                    break;

            }
        }
    };

}


