package com.hdh.billiardsapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BuilDB extends SQLiteOpenHelper {

    public BuilDB(Context context){
        super(context,"admin",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query ="create table if not exists admin " +
                "(Ad_id VARCHAR(50) PRIMARY KEY, " +
                "Ad_pass INTEGER NOT NULL, " +
                "Ad_name VARCHAR(50) NOT NULL, "  +
                "Ad_phon INTEGER NOT NULL) ;" ;

        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS admin");
        onCreate(db);

    }


}
