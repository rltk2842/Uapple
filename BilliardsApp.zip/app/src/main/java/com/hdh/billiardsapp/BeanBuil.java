package com.hdh.billiardsapp;

public class BeanBuil {

    String id;
    String pw;
    String na;
    String ph;
}
