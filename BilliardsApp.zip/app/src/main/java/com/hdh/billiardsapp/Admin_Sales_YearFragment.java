package com.hdh.billiardsapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import static com.hdh.billiardsapp.R.layout.fragment_year;


public class Admin_Sales_YearFragment extends Fragment {



    int nowY;
    int subY;

    Calendar cal = Calendar.getInstance();

    ArrayList<BeanSales> ars;


    TextView nYear;


    Button ybtnS, ybtnA;

    ListView listY;

    SQLiteDatabase sqlDB;
    SalesDB salesDB;

    SimpleAdapter SAD;

    ArrayList<HashMap<String,String>> arrList = new ArrayList<>();


    String jk;

    public Admin_Sales_YearFragment() {
        // Required empty public constructor

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        salesDB = new SalesDB(getActivity());
        sqlDB = salesDB.getReadableDatabase();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        arrList.clear();

        SAD = new SimpleAdapter(getActivity(),
                arrList,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});




        nowY = cal.get(Calendar.YEAR);
        subY = nowY;

        String Ycal = nowY + "년";

        View view = inflater.inflate(fragment_year, container, false);


        nYear = (TextView)view.findViewById(R.id.nYear);
        ybtnS = (Button)view.findViewById(R.id.ybtnS);
        ybtnA = (Button)view.findViewById(R.id.ybtnA);
        listY = view.findViewById(R.id.listY);

        jk =String.valueOf(subY) ;
        ars = salesDB.selcetdatey(sqlDB,subY);

        listY.setAdapter(SAD);



        for (int i = 0; i < ars.size(); i++) {
            HashMap<String, String> item = new HashMap<>();


            item.put("item1", String.valueOf(ars.get(i).getSaYear() + "년"));
            item.put("item2", String.valueOf("시간 :" +ars.get(i).getSaTime() +" 금액 :"+ars.get(i).getSaMoney()));
            arrList.add(item);

        }



        SAD.notifyDataSetChanged();

        //sqlDB.close();



        nYear.setText(Ycal);

        ybtnS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              adFragmentBtn(-1);


                SAD.notifyDataSetChanged();
                listY.setAdapter(SAD);
            }
        });

        ybtnA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adFragmentBtn(1);


                SAD.notifyDataSetChanged();
                listY.setAdapter(SAD);
            }
        });



        // Inflate the layout for this fragment
        return view;
    }


    public void adFragmentBtn(int a){
        arrList.clear();
        subY = subY + a;
        String SYcal = subY + "년";
        nYear.setText(SYcal);

        SAD = new SimpleAdapter(getActivity(),
                arrList,
                android.R.layout.simple_list_item_2,
                new String[]{"item1","item2"},
                new int[] {android.R.id.text1,android.R.id.text2});

        ars = salesDB.selcetdatey(sqlDB,subY);

        for (int i = 0; i < ars.size(); i++) {
            HashMap<String, String> item = new HashMap<>();

            item.put("item1", String.valueOf(ars.get(i).getSaYear() + "년"));
            item.put("item2", String.valueOf("시간 :" +ars.get(i).getSaTime() +" 금액 :"+ars.get(i).getSaMoney()));
            arrList.add(item);

        }


    }


    public ArrayList<BeanSales> select(SQLiteDatabase db){
        ArrayList<BeanSales> list = new ArrayList<>();
//        ars.clear();

        salesDB = new SalesDB(getActivity());

        Cursor cur;

        String query = "Select Sa_Year,Sa_Month,Sa_Day,Sa_Time,Sa_Money From sales;";

        try{
            cur = db.rawQuery(query,null);

            while(cur.moveToNext()){

                BeanSales ss = new BeanSales();
                ss.saYear = cur.getInt(0);
                ss.saMonth = cur.getInt(1);
                ss.saDay = cur.getInt(2);
                ss.saTime = cur.getInt(3);
                ss.saMoney = cur.getInt(4);

                ars.add(ss);


            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return list;

    }






}


